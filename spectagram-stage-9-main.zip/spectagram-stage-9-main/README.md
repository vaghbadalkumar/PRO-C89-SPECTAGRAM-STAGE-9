# spectagram-stage-9
project solution c89
